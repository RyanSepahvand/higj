'use strict';

document.addEventListener('DOMContentLoaded', function () {

  /**
   * Navbar variables and functionality
   */

  const navOpenBtn = document.querySelector("[data-menu-open-btn]");
  const navCloseBtn = document.querySelector("[data-menu-close-btn]");
  const navbar = document.querySelector("[data-navbar]");
  const overlay = document.querySelector("[data-overlay]");

  const navElemArr = [navOpenBtn, navCloseBtn, overlay];

  for (let i = 0; i < navElemArr.length; i++) {
    navElemArr[i].addEventListener("click", function () {
      navbar.classList.toggle("active");
      overlay.classList.toggle("active");
      document.body.classList.toggle("active");
    });
  }

  /**
   * Header sticky functionality
   */

  const header = document.querySelector("[data-header]");

  window.addEventListener("scroll", function () {
    window.scrollY >= 10 ? header.classList.add("active") : header.classList.remove("active");
  });

  /**
   * Go top button functionality
   */

  const goTopBtn = document.querySelector("[data-go-top]");

  window.addEventListener("scroll", function () {
    window.scrollY >= 500 ? goTopBtn.classList.add("active") : goTopBtn.classList.remove("active");
  });

  /**
   * Search functionality with highlighting
   */

  function handleSearch(event) {
    event.preventDefault(); // Prevent form submission

    const searchTerm = document.getElementById('search').value.trim().toLowerCase();

    if (!searchTerm) {
      removeHighlights();
      return;
    }

    removeHighlights(); // Clear existing highlights

    const searchRegex = new RegExp(searchTerm, 'gi');

    const firstMatch = highlightMatches(document.body, searchRegex);
    
    if (firstMatch) {
      // Scroll to the first matched element
      firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function highlightMatches(element, searchRegex) {
    let firstMatch = null;

    if (element.nodeType === Node.TEXT_NODE) {
      // Handle text nodes
      const matches = element.nodeValue.match(searchRegex);
      if (matches) {
        const fragment = document.createDocumentFragment();
        let lastIndex = 0;
        matches.forEach(match => {
          const before = element.nodeValue.substring(lastIndex, element.nodeValue.indexOf(match));
          const matchNode = document.createElement('span');
          matchNode.classList.add('highlight');
          matchNode.textContent = match;
          fragment.appendChild(document.createTextNode(before));
          fragment.appendChild(matchNode);
          lastIndex += before.length + match.length;

          // Store the first matched element for scrolling
          if (!firstMatch) {
            firstMatch = matchNode;
          }
        });
        const after = element.nodeValue.substring(lastIndex);
        fragment.appendChild(document.createTextNode(after));
        element.parentNode.replaceChild(fragment, element);
      }
    } else if (element.nodeType === Node.ELEMENT_NODE && element.nodeName !== 'SCRIPT' && element.nodeName !== 'STYLE') {
      // Recursively search child nodes
      Array.from(element.childNodes).forEach(child => {
        const matchedElement = highlightMatches(child, searchRegex);
        if (matchedElement && !firstMatch) {
          firstMatch = matchedElement;
        }
      });
    }

    return firstMatch;
  }

  function removeHighlights() {
    const highlights = document.querySelectorAll('.highlight');
    highlights.forEach(highlight => {
      highlight.outerHTML = highlight.innerHTML;
    });
  }

  const searchForm = document.querySelector('.search-form');
  searchForm.addEventListener('submit', handleSearch);

});

document.getElementById('tvseries').addEventListener('click', function() {
  document.getElementById('tvseriestarget').scrollIntoView({ behavior: 'smooth' });
});

document.getElementById('watchmore').addEventListener('click', function() {
  document.getElementById('watchmoretarget').scrollIntoView({ behavior: 'smooth' });
});